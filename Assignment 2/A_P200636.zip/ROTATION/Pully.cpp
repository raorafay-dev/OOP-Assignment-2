#include <iostream>
using namespace std;
#include "pully.h"

// for class "pully"

// default constructor
pully ::pully() {}

// parameterized constructor
pully ::pully(int r)
{
    radius = r;
}

// setter
void pully ::setter(int r)
{
    radius = r;
}

// getter
int pully ::get_radius()
{
    return radius;
}

// fuinction for getting circumference
float pully ::circumference(int r)
{
    float cr;

    // circumference of circle = 2 pi r
    cr = (2 * 3.14 * r);

    return cr;
}
