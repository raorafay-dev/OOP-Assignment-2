#include <iostream>
using namespace std;
#include "pully.h"
#include "rope.h"
#include "rotation.h"

int main()
{
    rotation r1;
    cout << r1.Rotatingthepully(5, 100, 2);
    return 0;
}