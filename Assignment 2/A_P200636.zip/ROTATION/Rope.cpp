#include <iostream>
using namespace std;
#include "rope.h"

// for class "rope"

// default constructor
rope ::rope() {}

// parameterized constructor
rope ::rope(int w, int l)
{
    width = w;
    length = l;
}

// setter
void rope ::setter(int w, int l)
{
    width = w;
    length = l;
}

// getters
int rope ::get_width() // for width
{
    return width;
}

int rope ::get_length() // for length
{
    return length;
}

