#ifndef ROPE_H
#define ROPE_H

class rope // for rope
{
    // private:
    int width;
    int length;

public:
    // default constructor
    rope();

    // parameterized constructor
    rope(int ,int);

    // setter
    void setter(int, int);

    // getters
    int get_width();  // for width
    
    
    int get_length(); // for length
    

    friend class rotation; // freind declaration to access the private data members
};

#endif