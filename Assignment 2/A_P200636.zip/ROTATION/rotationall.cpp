#include <iostream>
using namespace std;

class pully // for pully
{
    // private:

    int radius;

public:
    // default constructor
    pully() {}

    // parameterized constructor
    pully(int r)
    {
        radius = r;
    }

    // setter
    void setter(int r)
    {
        radius = r;
    }

    // getter
    int get_radius() // for radius
    {
        return radius;
    }

    // fuinction for getting circumference
    float circumference(int r)
    {
        float cr;

        // circumference of circle = 2 pi r
        cr = (2 * 3.14 * r);

        return cr;
    }

    friend class rotation; // freind declaration to access the private data members
};

class rope // for rope
{
    // private:
    int width;
    int length;

public:
    // default constructor
    rope() {}

    // parameterized constructor
    rope(int w, int l)
    {
        width = w;
        length = l;
    }

    // setter
    void setter(int w, int l)
    {
        width = w;
        length = l;
    }

    // getters
    int get_width()  // for width
    {
        return width;
    }
    
    int get_length() // for length
    {
        return length;
    }

    friend class rotation; // freind declaration to access the private data members
};

class rotation // for rotation
{
public:
    int Rotatingthepully(int r, int l, int w)
    {
        // as there is no object passed in parameter yso we will create (temporary objects) of class "pully" and "rope"
        pully objp;
        rope objr;

        // setting/initializing values by calling defined setter functions of classes
        objp.setter(r);
        objr.setter(w, l);

        // getting circumference
        float cr = objp.circumference(r);


        // counting rotations per iterations
        int rot = 0;

        // iterating while length is geater than circumference
        while (l > cr)
        {
            // adding rotation
            rot++;

            // on each rotation length decrease according circumference
            l -= cr;

            // radius will increase according width of rope
            r += w;

            // circumference will also accordingly increase as the radius is increasing
            cr = objp.circumference(r);
        }

        // returning rotations  
        return rot;
    }
};

int main()
{
    rotation r1;
    cout << r1.Rotatingthepully(0, 100, 1);
    return 0;
}