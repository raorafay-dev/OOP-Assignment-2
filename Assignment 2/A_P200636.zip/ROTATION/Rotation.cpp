#include <iostream>
using namespace std;
#include "rotation.h"
#include "pully.h"
#include "rope.h"

// for class rotation

int rotation ::Rotatingthepully(int r, int l, int w)
{
    // as there is no object passed in parameter yso we will create (temporary objects) of class "pully" and "rope"
    pully objp;
    rope objr;

    // setting/initializing values by calling defined setter functions of classes
    objp.setter(r);
    objr.setter(w, l);

    // getting circumference
    float cr = objp.circumference(r);

    // counting rotations per iterations
    int rot = 0;

    // iterating while length is geater than circumference
    while (l > cr)
    {
        // adding rotation
        rot++;

        // on each rotation length decrease according circumference
        l -= cr;

        // radius will increase according width of rope
        r += w;

        // circumference will also accordingly increase as the radius is increasing
        cr = objp.circumference(r);
    }

    // returning rotations
    return rot;
}