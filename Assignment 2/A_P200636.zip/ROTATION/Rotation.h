#ifndef ROTATION_H
#define ROTATION_H


class rotation // for rotation
{
public:
    int Rotatingthepully(int, int, int);
};

#endif