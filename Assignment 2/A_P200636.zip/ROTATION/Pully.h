#ifndef PULLY_H
#define PULLY_H

class pully // for pully
{
    // private:

    int radius;

public:
    // default constructor
    pully();

    // parameterized constructor
    pully(int);

    // setter
    void setter(int);

    // getter
    int get_radius(); // for radius

    // fuinction for getting circumference
    float circumference(int);

    friend class rotation; // freind declaration to access the private data members
};
   

#endif