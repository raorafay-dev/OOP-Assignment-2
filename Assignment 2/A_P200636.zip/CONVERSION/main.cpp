#include <iostream>
using namespace std;
#include "conversion.h"

int main()
{
    Conversion C("121");
    C.ToHexaDecimal("10");

    return 0;
}
